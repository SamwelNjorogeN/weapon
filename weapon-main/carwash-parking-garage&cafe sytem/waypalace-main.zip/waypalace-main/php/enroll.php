<?php
include '../php/connect.php';

$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$nationalID = $_POST['nationalID'];
$p_no = $_POST['p_no'];
$model = $_POST['model'];
$regno = $_POST['regno'];
$email = $_POST['email'];
$pass = $_POST['pass'];

// Hash the password
$hashed_password = password_hash($pass, PASSWORD_DEFAULT);

$stmt = mysqli_query($conn, "INSERT INTO enroll(fname, lname, mname, nationalID, p_no, regno, model, email, pass)
                             VALUES ('$fname', '$lname', '$mname', '$nationalID', '$p_no', '$regno', '$model', '$email', '$hashed_password')");


    // Check if email and nationalID are unique
    $check_duplicate = "SELECT * FROM enroll WHERE email = ? OR nationalID = ?";
    $stmt_check = $conn->prepare($check_duplicate);
    $stmt_check->bind_param("ss", $email, $nationalID);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        echo "<div id='overlay' style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 999; display: flex; justify-content: center; align-items: center;'>
        <div style='background-color: white; padding: 20px; border-radius: 10px; text-align: center;'>
            <h2 style='color: red;'>National ID and Email Already Registered !</h2>
            <button class='login100-form-bgbtn' style='color: white; width: 100px; height: 30px; font-weight: bolder; border-radius: 30px; border: none; cursor: pointer; background: #a64bf4; background: -o-linear-gradient(right, #21d4fd, #b721ff, #21d4fd, #b721ff); background: -moz-linear-gradient(right, #21d4fd, #b721ff, #21d4fd, #b721ff); background: linear-gradient(right, #21d4fd, #b721ff, #21d4fd, #b721ff);'onclick=\"window.location.href = '../html/signup.php';\">OK</button>
        </div>
    </div>";
        exit; // Stop further execution if duplicate found
    }

if ($stmt) {
    echo '<script>alert("Registration successful!"); window.location.href = "http://localhost/waypalace/html/login.php";</script>';
} else {
    echo "You have Encountered a Technical Error Please Contact Admin";
}
$conn->close();
?>
