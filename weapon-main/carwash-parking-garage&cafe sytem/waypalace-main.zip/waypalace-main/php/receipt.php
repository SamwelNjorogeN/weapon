<?php
include '../php/connect.php';
// Fetch the latest payment record
$stmt_select = $conn->prepare("SELECT * FROM payment ORDER BY id DESC LIMIT 1");
$stmt_select->execute();
$result = $stmt_select->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $clientName = $row['fname'] . ' ' . $row['lname'];
    $task = $row['task'];
    $amount = $row['paidamount'];
} else {
    // Set error message if no records found
    $errorMsg = "No Records Found";
}
$stmt_select->close();

