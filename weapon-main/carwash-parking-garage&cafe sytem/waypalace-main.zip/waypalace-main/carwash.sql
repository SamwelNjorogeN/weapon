-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 08:09 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carwash`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `fname` varchar(40) NOT NULL,
  `mname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `nationalID` int(11) NOT NULL,
  `p_no` int(15) NOT NULL,
  `regno` varchar(10) NOT NULL,
  `task` varchar(60) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`fname`, `mname`, `lname`, `nationalID`, `p_no`, `regno`, `task`, `amount`) VALUES
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', '', 3500),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Wheel Cleaning', 656),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Wheel Cleaning', 656),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Bug and Tar Removal', 23),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Soft-Cloth Wash', 23),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Detailing Service', 12000),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Detailing Service', 12000),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Detailing Service', 12000),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Eco-Friendly Wash', 222),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Wheel Cleaning', 45),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Wheel Cleaning', 45),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Wheel Cleaning', 450),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'Automatic/Touchless Wash', 233),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'Express Wash', 2500),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP295E', 'Wheel Cleaning', 2500);

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `fname` varchar(40) NOT NULL,
  `mname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `nationalID` int(20) NOT NULL,
  `p_no` int(15) NOT NULL,
  `regno` varchar(10) NOT NULL,
  `model` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `pass` varchar(8000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`fname`, `mname`, `lname`, `nationalID`, `p_no`, `regno`, `model`, `email`, `pass`) VALUES
('', '', '', 0, 0, '', '', '', ''),
('', '', '', 0, 0, '', '', '', ''),
('', '', '', 0, 0, '', '', '', ''),
('', '', '', 0, 0, '', '', '', ''),
('', '', '', 0, 0, '', '', '', ''),
('', '', '', 0, 0, '', '', '', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Karanja', 'Njoroge', 0, 793878068, 'LORRY MAZD', 'KBP268E', 'smhc@gmail.com', ''),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'smhc@gmail.com', ''),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'smhc@gmail.com', ''),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'smhc@gmail.com', 'Routesoft-Admin'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'smhc@gmail.com', 'Routesoft-Admin'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'kiki@gmail.com', 'mkikimkiki'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'kiki@gmail.com', 'mkikimkiki'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'kiki@gmail.com', 'mkikimkikir'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'kiki@gmail.com', '$2y$10$gLHf8ImqtpKyzDmK3Ej55OGJ8inuBw86K4AX8kMqw7kvhkiDtk7hG'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'samwelnjoroge757@gmail.com', '$2y$10$ocQDaEKFvggTXEXupmcXxev3dWCZCckT/awiqpWX2wJ2Ohsj8dA.W'),
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'KBP268E', 'LORRY MAZDA', 'samnjoroge757@gmail.com', '$2y$10$U5/1ajgs3ejmeE.hfAC8M.uNd2mn6OfTHgoLN/zOpfAk6yaVhYtim'),
('Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'KBP268E', 'LORRY MAZDA', 'samwel@gmail.com', '$2y$10$l61YF9fIxnfyaNDm8AJNmu2YCRlgOk2K3H7fctDcS0UVWACglDCei'),
('Samwel', 'Njoroge', 'Karanja', 1234567, 793878068, 'KBP268E', 'LORRY MAZDA', 'samwel@gmail.com', '$2y$10$iUmeovh7bpzhzAmYM9/oKeZ/T9uaLLfJCj.oWUIUlapxQ5Gx2vBoW'),
('Samwel', 'Njoroge', 'Karanja', 757, 793878068, 'KBP268E', 'LORRY MAZDA', 'kenya@gmail.com', '$2y$10$QeEh9xSU42N05zWyVES0W.iDOiVTJLXgv2ytDFm/Uu2XaZu71.DpK'),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'LORRY MAZDA', 'samwelnjoroge757@gmail.com', '$2y$10$lGeAWdKTZXcfvtpQ86Dw9O7v51v8u8m0sEHHxkKdaOyHX/5rnwl9e'),
('Samwel', 'Njoroge', 'Karanja', 38229299, 793878068, 'KBP268E', 'LORRY MAZDA', 'samwelnjoroge757@gmail.com', '$2y$10$hoKwpUMPtjkFtKFUTyOisOCeeccb/vpQ7dqZ2l.OK0Yeqv6ln/aye');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `nationalID` int(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `login_time` time NOT NULL,
  `login_date` date NOT NULL,
  `usertype` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `nationalID`, `email`, `login_time`, `login_date`, `usertype`) VALUES
(1, 0, 'samwelnjoroge757@gmail.com', '12:53:55', '2024-03-28', ''),
(2, 0, 'samwelnjoroge757@gmail.com', '13:04:58', '2024-03-28', ''),
(3, 0, 'samnjoroge757@gmail.com', '13:07:15', '2024-03-28', ''),
(4, 0, 'samnjoroge757@gmail.com', '13:14:04', '2024-03-28', ''),
(5, 0, 'samwelnjoroge757@gmail.com', '13:15:05', '2024-03-28', ''),
(6, 0, 'samnjoroge757@gmail.com', '13:30:46', '2024-03-28', ''),
(7, 757, 'kenya@gmail.com', '13:33:56', '2024-03-28', ''),
(8, 757, 'kenya@gmail.com', '15:36:23', '2024-03-28', ''),
(9, 757, 'kenya@gmail.com', '15:42:23', '2024-03-28', ''),
(10, 757, 'kenya@gmail.com', '15:42:40', '2024-03-28', ''),
(11, 757, 'kenya@gmail.com', '15:50:20', '2024-03-28', ''),
(12, 757, 'kenya@gmail.com', '16:33:27', '2024-03-28', ''),
(13, 757, 'kenya@gmail.com', '14:11:33', '2024-04-03', ''),
(14, 757, 'kenya@gmail.com', '14:35:16', '2024-04-03', 'client'),
(15, 0, 'samnjoroge757@gmail.com', '14:39:04', '2024-04-03', 'client'),
(16, 0, 'samnjoroge757@gmail.com', '14:40:47', '2024-04-03', 'client'),
(17, 0, 'samnjoroge757@gmail.com', '15:07:57', '2024-04-03', 'client');

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE `parking` (
  `userID` int(11) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `mname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `nationalID` int(20) NOT NULL,
  `phonenumber` int(15) NOT NULL,
  `model` varchar(10) NOT NULL,
  `registration` varchar(40) NOT NULL,
  `date` varchar(60) NOT NULL,
  `time` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parking`
--

INSERT INTO `parking` (`userID`, `fname`, `mname`, `lname`, `nationalID`, `phonenumber`, `model`, `registration`, `date`, `time`) VALUES
(1, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 2147483647, 'LORRY MAZD', '12dfvf', '', ''),
(2, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 2147483647, 'LORRY MAZD', '12dfvf', '', ''),
(3, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 2147483647, 'LORRY MAZD', '12dfvf', '2024-04-04', '11:09:04'),
(4, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 2147483647, 'LORRY MAZD', '12dfvf', '2024-04-04', '12:09:52'),
(5, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '12:18:04'),
(6, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '12:21:43'),
(7, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '12:21:47'),
(8, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '12:22:27'),
(9, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '12:22:31'),
(10, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:24:47'),
(11, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:27:06'),
(12, 'Samwel', 'Njoroge', 'Karanja', 1234567890, 2147483647, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:28:43'),
(13, 'Samwel', 'Njoroge', 'Karanja', 38229299, 2147483647, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:37:31'),
(14, 'Samwel', 'Njoroge', 'Karanja', 38229299, 2147483647, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:47:19'),
(15, 'Samwel', 'Njoroge', 'Karanja', 38229299, 2147483647, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '11:49:38'),
(16, 'Samwel', 'Njoroge', 'Karanja', 1234567, 793878068, 'LORRY MAZD', '12dfvfyh', '2024-04-04', '19:12:59');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `fname` varchar(60) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `task` varchar(60) NOT NULL,
  `regno` varchar(60) NOT NULL,
  `p_no` varchar(15) NOT NULL,
  `paidamount` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`fname`, `lname`, `task`, `regno`, `p_no`, `paidamount`) VALUES
('Samwel', 'Karanja', 'Wheel cleaning', 'KBP268G', '254793878068', 2500);

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `HandWash` int(11) DEFAULT NULL,
  `SoftClothWash` int(11) NOT NULL,
  `SelfServiceWash` int(11) NOT NULL,
  `DetailingService` int(11) NOT NULL,
  `AutomaticTouchlessWash` int(11) NOT NULL,
  `UndercarriageWash` int(11) NOT NULL,
  `WheelCleaning` int(11) NOT NULL,
  `BugTarRemoval` int(11) NOT NULL,
  `EcoFriendlyWash` int(11) NOT NULL,
  `ExpressWash` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`HandWash`, `SoftClothWash`, `SelfServiceWash`, `DetailingService`, `AutomaticTouchlessWash`, `UndercarriageWash`, `WheelCleaning`, `BugTarRemoval`, `EcoFriendlyWash`, `ExpressWash`) VALUES
(2500, 3000, 1500, 3000, 1000, 3000, 2500, 2000, 2500, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fname` varchar(60) NOT NULL,
  `mname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `nationalID` int(11) NOT NULL,
  `p_no` int(11) NOT NULL,
  `usertype` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fname`, `mname`, `lname`, `nationalID`, `p_no`, `usertype`, `email`, `pass`) VALUES
('Samwel', 'Njoroge', 'Karanja', 0, 793878068, 'Admin', 'samwelnjoroge757@gmail.com', '$2y$10$i4FfiXJoEEHRLzN6/1tIjeS'),
('Samwel', 'Njoroge', 'Karanja', 12345, 793878068, 'Admin', 'samwelnjoroge757@gmail.com', '$2y$10$xFDUTUmnkR/IdrC5xmRKw.T'),
('Samwel', 'Njoroge', 'Karanja', 12345, 793878068, 'Admin', 'samwelnjoroge757@gmail.com', '$2y$10$RwAzKqVztqGZ6DE0HQtHJOW'),
('Samwel', 'Njoroge', 'Karanja', 12345, 793878068, 'Admin', 'samwelnjoroge757@gmail.com', '$2y$10$x9ho0I.afeRtV7rCtfUmBOy'),
('Samwel', 'Njoroge', 'Karanja', 12345, 793878068, 'Admin', 'samwelnjoroge757@gmail.com', '$2y$10$LC0eqEqDzPI8W1CigORAvuJ'),
('Samwel', 'Njoroge', 'Karanja', 123452, 793878068, 'Admin', 'samwelnjorog757@gmail.com', '$2y$10$2ZceaaMQRYFru7CI.kV.quw'),
('Samwel', 'Njoroge', 'Karanja', 1, 793878068, 'Choose User Type', 'mwelnjoroge757@gmail.com', '$2y$10$bQhzLPVRIk32Qk0VilUi6ub'),
('Samwel', 'Njoroge', 'Karanja', 90, 793878068, 'Receptionist', 'samwelnjoroge57@gmail.com', '$2y$10$QfyoYlk5Lk2dY5iNRik6M.G'),
('Alice', 'Mwangi', 'Wairimu', 9756456, 2147483647, 'Receptionist', 'alicemwangi@gmail.com', '$2y$10$fZKZhPmnvcV23gfrwiSdKeA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parking`
--
ALTER TABLE `parking`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `parking`
--
ALTER TABLE `parking`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
